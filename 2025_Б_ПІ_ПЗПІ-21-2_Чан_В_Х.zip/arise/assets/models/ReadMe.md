Option 1: Auto-download sample models

```bash
cmake -DUSE_GLTF_SAMPLE_MODELS=ON ..
```

Option 2: Add your models manually

- Place `.gltf` and `.glb` files here
- Or in subdirectories (`gltf/`, `obj/`, etc.)

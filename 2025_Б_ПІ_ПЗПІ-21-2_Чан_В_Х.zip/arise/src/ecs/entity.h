#ifndef ARISE_ENTITY_H
#define ARISE_ENTITY_H

#include <entt/entt.hpp>

namespace arise {

using Entity = entt::entity;

}  // namespace arise

#endif  // ARISE_ENTITY_H
